package Conexcion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



/**
 * Clase de prueba de conexión con una base de datos MySQL
 */
public class Datos {
    
    Connection con;
    public   Datos(){
       
     
        // Se mete todo en un try por los posibles errores de MySQL
        try{
            
            con= DriverManager.getConnection ("jdbc:mysql://localhost/parqueo","root", "");
                        
        }
        catch (SQLException e){
           
        }        
        
    }   
    public Connection getConnection(){
    
        return con;
    }      
    
}

